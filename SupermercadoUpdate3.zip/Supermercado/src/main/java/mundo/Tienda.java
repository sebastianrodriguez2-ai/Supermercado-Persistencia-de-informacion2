/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

import java.io.RandomAccessFile;
import java.util.List;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author USUARIO
 */
public class Tienda {
    private static final int TAM_NOMBRE = 27;
    private static final int TAM_ESTADO = 10;
    private static final int TAM_REGISTRO = 54;

    public static boolean guardarEnArchivo(Producto p) {
        try {
            RandomAccessFile file = new RandomAccessFile("data//Productos.txt", "rw");
            file.seek(file.length());
            file.writeInt(p.getCodigo());
            file.writeUTF(String.format("%-" + TAM_NOMBRE + "s", p.getNombre()).substring(0, TAM_NOMBRE));
            file.writeDouble(p.getPrecio());
            file.writeBoolean(p.isPerecedero());
            file.writeUTF(String.format("%-" + TAM_ESTADO + "s", p.getEstado()).substring(0, TAM_ESTADO));
            file.close();
        } catch (Exception ex) {
            Logger.getLogger(Tienda.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    public static List<Producto> getProductos() {
        int codigo;
        String nombre;
        double precio;
        boolean perecedero;
        String estado;
        
        List<Producto> productos = new ArrayList<>();

        try {
            RandomAccessFile file = new RandomAccessFile("data//Productos.txt", "r");
            file.seek(0);
            while (file.getFilePointer() < file.length()) {
                codigo = file.readInt();
                nombre = file.readUTF().trim();
                precio = file.readDouble();
                perecedero = file.readBoolean();
                estado = file.readUTF();

                Producto p = new Producto(codigo, nombre, precio, perecedero, estado);
                productos.add(p);
            }
            file.close();

        } catch (Exception ex) {
            Logger.getLogger(Tienda.class.getName()).log(Level.SEVERE, null, ex);
        }
        return productos;
    }

    public static Producto buscarProducto(int codigoBuscado) {
        int codigo;
        String nombre;
        double precio;
        boolean perecedero;
        String estado;
        
        try {
            RandomAccessFile file = new RandomAccessFile("data//Productos.txt", "r");
            while (file.getFilePointer() < file.length()) {
                codigo = file.readInt();
                nombre = file.readUTF();
                precio = file.readDouble();
                perecedero = file.readBoolean();
                estado = file.readUTF();

                if (codigo == codigoBuscado) {
                    file.close();
                    return new Producto(codigo, nombre, precio, perecedero, estado);
                }
            }
            file.close();
        } catch (Exception ex) {
            Logger.getLogger(Tienda.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public static boolean eliminarProducto(int codigoBuscado) {
        int codigo;
        String nombre;
        double precio;
        boolean perecedero;
        String estado;
        
        try {
        RandomAccessFile file = new RandomAccessFile("data//Productos.txt", "rw");
        file.seek(0);
        while (file.getFilePointer() < file.length()) {
            codigo = file.readInt();
            nombre = file.readUTF();       
            precio = file.readDouble();    
            perecedero = file.readBoolean();
            estado = file.readUTF();

            if (codigo == codigoBuscado) {
                file.seek(file.getFilePointer() - TAM_REGISTRO);
                file.readInt();
                file.readUTF();
                file.readDouble();
                file.readBoolean();
                file.writeUTF(String.format("%-" + TAM_ESTADO + "s", "Inactivo").substring(0, TAM_ESTADO));
                file.close();
                return true;
            }
        }
        file.close();
    } catch (Exception ex) {
        Logger.getLogger(Tienda.class.getName()).log(Level.SEVERE, null, ex);
    }
    return false;
}
    
    public static boolean actualizarProductos (Producto emp){
        int codigo;
        String nombre;
        double precio;
        boolean perecedero;
        String estado;
        
        try{
            RandomAccessFile file = new RandomAccessFile("data//Productos.txt", "rw");
            file.seek(0);
            while (file.getFilePointer() < file.length()) {
                codigo     = file.readInt();
                nombre     = file.readUTF().trim();
                precio     = file.readDouble();
                perecedero = file.readBoolean();
                estado     = file.readUTF().trim();

                if (codigo == emp.getCodigo()) {
                    file.seek(file.getFilePointer() - TAM_REGISTRO);
                    file.writeInt(emp.getCodigo());
                    file.writeUTF(String.format("%-" + TAM_NOMBRE + "s", emp.getNombre()).substring(0, TAM_NOMBRE));
                    file.writeDouble(emp.getPrecio());
                    file.writeBoolean(emp.isPerecedero());
                    file.writeUTF(String.format("%-" + TAM_ESTADO + "s", emp.getEstado()).substring(0, TAM_ESTADO));
                    file.close();
                    return true;
                }
            }
            file.close();
        } catch (Exception ex) {
            Logger.getLogger(Tienda.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public static double calcularSuma() {
        int codigo;
        String nombre;
        double precio;
        boolean perecedero;
        String estado;
        
        double sumatoria = 0;
        
        try {
        RandomAccessFile file = new RandomAccessFile("data//Productos.txt", "r");
        file.seek(0);
        while (file.getFilePointer() < file.length()) {
            codigo     = file.readInt();
            nombre     = file.readUTF();
            precio     = file.readDouble();
            perecedero = file.readBoolean();
            estado     = file.readUTF().trim();
            
            if (estado.equals("Activo")) {
                sumatoria += precio;
            }
        }
        file.close();
        } catch(Exception ex) {
            Logger.getLogger(Tienda.class.getName()).log(Level.SEVERE, null, ex);
        }
        return sumatoria;
    }
}
