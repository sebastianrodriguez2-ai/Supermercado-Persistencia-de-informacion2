/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package interfaz;

/**
 *
 * @author USUARIO
 */
public class Supermercado {

    public static void main(String[] args) {
        GUIPrincipal gui = new GUIPrincipal();
        gui.setVisible(true);
        
    }
}
